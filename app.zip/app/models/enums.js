'use strict';
//var b=10;
//exports.getB = function() { return b; };
module.exports={
    unit:['l','kg','ton']

}

